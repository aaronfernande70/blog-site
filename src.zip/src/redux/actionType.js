export const GET_BLOGS="GET_BLOGS"
// export const STORE_BLOGS="STORE_BLOGS"

export const GET_MY_BLOGS="GET_MY_BLOGS"

export const GET_USERS="GET_USERS"

export const GET_USER="GET_USER"

export const GET_CATEGORIES ="GET_CATEGORIES"



