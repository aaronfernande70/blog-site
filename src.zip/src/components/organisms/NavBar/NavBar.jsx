import React from 'react'

export default function NavBar() {
  return (
    <div>NavBar</div>
  )
}
