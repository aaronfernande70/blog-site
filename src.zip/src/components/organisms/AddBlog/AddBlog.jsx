import React from 'react'

export default function AddBlog() {
  return (
    <div>AddBlog</div>
  )
}
